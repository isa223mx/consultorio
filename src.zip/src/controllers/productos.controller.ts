import { Request, Response } from "express";

export const getAll = (req: any, res: any) => {
    const doctors = [
        { id: 1, name: "Dr. Juan Perez", specialty: "Cardiología" },
        { id: 2, name: "Dr. Maria Lopez", specialty: "Neurología" }
    ];

    const messages = doctors.map(doctor => {
        return `Doctor: ${doctor.name} Especialidad: ${doctor.specialty} ID: ${doctor.id}`;
    });

    res.status(200).json({ messages });
};