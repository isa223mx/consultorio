import express, { Request, Response } from 'express';
import productosRouter from './routers/productos.routers';


const app = express();
const port = 3000;

app.get('/', (req: Request, res: Response) => {
  res.send('¡Hola,vienvenido usuario');
});
app.use(express.json());
app.use("/productos", productosRouter);

app.listen(port, () => {
  console.log(`escuchando puerto:${port}`);
}

);