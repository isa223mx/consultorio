import { Router} from "express";
import { getAll } from "../controllers/productos.controller";
const router = Router();


router.get("/consultorio", getAll);
export default router;
